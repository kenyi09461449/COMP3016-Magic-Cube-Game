#pragma once 
#include "pch.h"
#include "RubikCube.h"


//�켣��
//Trace ball
class TraceBall
{

public:
    TraceBall() {}
     glm::vec3 MapToSphere(const glm::vec2 pos2D) {
         //pos2D�Ѿ�������ӳ�䵽��-1��1�����������ǵ�������x^2+y^2+z^2��1��
        //pos2D had been remapped to (-1,1) and our sphere is x^2+y^2+z^2=1.
        glm::vec3 pos3D(1.0);
        float d = glm::length(pos2D);
        if (d < sqrt(2.0))
            pos3D = glm::vec3(pos2D, sqrt(1 - d * d));
        else
            //�������Բ�⣬����ͶӰ��Բ������ĵ㡣
            //if the point is outside the circle,project it to the nearest point on the circle.
            pos3D = glm::vec3(glm::normalize(pos2D), 0.0f);
        return pos3D;
    }

     void LMouseClick(glm::vec2 pos)
     {
         leftClickSpherePos = MapToSphere(pos);
         ClickMatrix_ = RubikCube_p->Matrix;
     }
     void RMouseClick(glm::vec2 pos)
     {
         rightClickSpherePos = MapToSphere(pos);
     }
     void MouseMove(glm::vec2 pos2D) {
         glm::vec3 curSpherePos = glm::vec3(0.0f);
         curSpherePos = MapToSphere(pos2D);

         glm::vec3 axis = glm::cross(leftClickSpherePos, curSpherePos);
         glm::vec3 axis_l = glm::vec3(glm::inverse(RubikCube_p->Matrix) * glm::vec4(axis, 1));
         float angle = glm::length(leftClickSpherePos - curSpherePos);
         RubikCube_p->Matrix = glm::rotate(ClickMatrix_, -angle, axis);
     }
     //������Ļ������㶯�����ĸ����layer,����ֵ��������һ������ֵ�����������Ƿ���1Ϊ����-1Ϊ��
     //Calculate which axis's layer is being moved based on the screen coordinates. There are two return values: the index of the coordinate value and the direction. 1 is positive and -1 is negative
     std::tuple<int, int> CalAxis(glm::vec2 _curPos, glm::mat4 global) {

         glm::vec3 curpos = MapToSphere(_curPos);
         std::cout << "click pos = " << rightClickSpherePos.x << "," << rightClickSpherePos.y << "," << rightClickSpherePos.z << "\t" << "curpos = " << curpos.x << "," << curpos.y << "," << curpos.z << std::endl;
         glm::vec3 axis_w = glm::cross(rightClickSpherePos, curpos);//world space axis
         glm::vec3 axis_l = glm::vec3(glm::inverse(global) * glm::vec4(axis_w, 1));//local space axis
         glm::normalize(axis_l);
         std::cout << "(drag axis)=" << axis_l.x << "," << axis_l.y << "," << axis_l.z << std::endl;
         //use dot product to find final axis
         float Xcomp = glm::dot(axis_l, glm::vec3(1.0f, 0.0f, 0.0f));
         float Ycomp = glm::dot(axis_l, glm::vec3(0.0f, 1.0f, 0.0f));
         float Zcomp = glm::dot(axis_l, glm::vec3(0.0f, 0.0f, 1.0f));
         std::tuple<int, int> axisDir;  //The return value is the coordinate and reverse direction of the axis//����ֵ���������ͷ���
         int axis;
         if (abs(Xcomp) > abs(Ycomp)) {
             if (abs(Xcomp) > abs(Zcomp))
             {
                 return Xcomp > 0 ? std::tuple{0, -1} : std::tuple{0, 1};   //x
             }
             else
             {
                 return Zcomp > 0 ? std::tuple{ 2, 1 } : std::tuple{ 2, -1 };   //z
             }//z
         }
         else if (abs(Ycomp) > abs(Zcomp))               
             return Ycomp > 0 ? std::tuple{ 1, 1 } : std::tuple{ 1, -1 };   //y
         else
             return Zcomp > 0 ? std::tuple{ 2, 1 } : std::tuple{ 2, -1 };   //z
     }
     
private:
    glm::vec3 leftClickSpherePos = glm::vec3(1.0);
    glm::vec3 rightClickSpherePos = glm::vec3(1.0);

public:
    RubikCube *RubikCube_p = nullptr;
    int restrictedAngle = 0;
    glm::mat4 ClickMatrix_ ;   //Left click on the matrix of the Rubik's Cube//������ʱħ���ľ���

};