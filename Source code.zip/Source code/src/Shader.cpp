#include "Shader.h"
#include <iostream>
#include <sstream>

Shader::Shader(std::string vsFile, std::string fsFile)
{
    //��ȡshader�ļ�
    //Read Shader File
    std::string vsSrc = ReadFile(vsFile);
    std::string fsSrc = ReadFile(fsFile);

	//����shader
    //Compile Shader
    uint vsId = CompileShader(vsSrc, GL_VERTEX_SHADER);
    uint fsId = CompileShader(fsSrc, GL_FRAGMENT_SHADER);

    //����shader
    //Link shader
    programId_ = glCreateProgram();
    glAttachShader(programId_, vsId);
    glAttachShader(programId_, fsId);
    glLinkProgram(programId_);
    CheckErrors(programId_, "LINK");
}


unsigned int Shader::CompileShader(std::string& src, uint type)
{
    const char* csSrc = src.c_str();
	uint id = glCreateShader(type);
	glShaderSource(id, 1, &csSrc, nullptr);
    //����
    //Compile
    glCompileShader(id);
    CheckErrors(id, "SHADER");
	return id;
}
void Shader::CheckErrors(uint id, std::string type)
{
    int success =1 ;
    char infoLog[1024];
    //���������
    //Check for compilation errors
    if (type == "SHADER")
    {
        glGetShaderiv(id, GL_COMPILE_STATUS, &success);
        if (!success)
        {
            glGetShaderInfoLog(id, 1024, NULL, infoLog);
            std::cout << "ERROR::SHADER_COMPILATION_ERROR of type: " << type << "\n" << infoLog << "\n -- --------------------------------------------------- -- " << std::endl;
        }
    }
    //������Ӵ���
    //Check for link errors
    else
    {
        glGetProgramiv(id, GL_LINK_STATUS, &success);
        if (!success)
        {
            glGetProgramInfoLog(id, 1024, NULL, infoLog);
            std::cout << "ERROR::PROGRAM_LINKING_ERROR of type: " << type << "\n" << infoLog << "\n -- --------------------------------------------------- -- " << std::endl;
        }
    }

}

std::string Shader::ReadFile(std::string path)
{
    std::ifstream ifs(path);
    if (!ifs.is_open())
    {
        std::cout << __FUNCTION__ << " Error " << std::endl;
        assert(0);
    }
    std::stringstream ss;
    ss << ifs.rdbuf();
    return ss.str();
}
