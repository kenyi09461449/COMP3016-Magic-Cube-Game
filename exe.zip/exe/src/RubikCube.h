#pragma once
#include "Cube.h"
#include "Shader.h"
#include "Texture.h"
#include "GlfwWindow.h"

//layer��ħ����һ���棬��layerΪ��λ������ת 
//Layer is a face of a Rubik's Cube that rotates in units of layer
struct Layer
{
	glm::vec3 cubes[3][3];
	glm::vec3 axis;
};
enum State
{
	None,InitRotating,Rotating
};

class RubikCube
{

public:
	RubikCube()
	{
		for (int x = 0; x < 3; x++)
			for (int y = 0; y < 3; y++)
				for (int z = 0; z < 3; z++)
				{
					//cubes��˳���Ǵ�����ϵķ�����ǰ��
					//The order of cubes is from  left back top to right front bottom
					cubes_[x][y][z].Pos_ = glm::vec3(x-1.0, -y+1.0, z-1.0);
					cubes_[x][y][z].Init();
				}

		InitLayer();
	};

	~RubikCube() {}
	void Render(Shader& shader, Texture& texture)
	{
		for (int x = 0; x < 3; x++)
			for (int y = 0; y < 3; y++)
				for (int z = 0; z < 3; z++)
				{
					//�����������ת��Ϊģ��ֵд��ģ�滺��
					//Convert the coordinates of the blocks to template values and write them into the template buffer
					shader.setMat4("model", Matrix * cubes_[x][y][z].RotationMatrix_ * cubes_[x][y][z].PosMatrix_);
					glStencilFunc(GL_ALWAYS, IndexToStencil(x, y, z), 0xFF);	
					cubes_[x][y][z].Render(shader, texture);
				}
	}
	void Update(float deltaTime, Shader& shader, Texture& texture)
	{
		//Update status
		if (State_ == Rotating)
		{
			float deltaAngle = RotateSpeed * deltaTime;
			if (angle < 90.0)
			{
				angle += RotateSpeed * deltaTime;
			}
			if (angle >= 90.0f)
			{
				rotateCountor += 1;
				deltaAngle = 90.0 - (angle - deltaAngle);
				angle = 90.0;

				isFinish = true;
			}

			//��ת��
			//Rotate Layer
			Layer* layer = &layers_[pickedLayer_.x][pickedLayer_.y];
			//������ת��
			//Traverse Rotation Layer
			for (int i = 0; i < 3; i++) {
				for (int j = 0; j < 3; j++) {
					glm::ivec3 cubeIndex = layer->cubes[i][j];
					Cube* curCube = &cubes_[cubeIndex.x][cubeIndex.y][cubeIndex.z];
					auto mat = glm::rotate(glm::mat4(1.0f), glm::radians(deltaAngle)* dragDirection, layer->axis);
					curCube->RotationMatrix_ = mat * curCube->RotationMatrix_;
				}
			}
		}

		Render(shader, texture);

		if (isFinish)
		{
			FinishAnimation();
			isFinish = false;
			State_ = None;
			angle = 0.0f;
		}
	}

	//����Ҽ����ʱ����
	//Triggered on right mouse click
	void RightButtonClick(glm::vec2 clickPos)
	{
		if (State_ == Rotating)
			return;
		uint stencil;
		glReadPixels(clickPos.x , (GLWindow::SCR_HEIGHT - clickPos.y) , 1, 1, GL_STENCIL_INDEX, GL_UNSIGNED_INT, &stencil);
		if (!StencilToIndex(stencil, pickedCube_)) return;
		std::cout << "stencil value:" << stencil << " picked: " << pickedCube_.x << " " << pickedCube_.y << " " << pickedCube_.z << " " << std::endl;
	}

	void FinishAnimation() {//save current transformation
	
		//�ѵ�ǰlayer��cube����������
		//Save the current layer's cube
		Cube changedcubes[3][3];
		Layer* layer = &layers_[pickedLayer_.x][pickedLayer_.y];

		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				glm::ivec3 cubeIndex = layer->cubes[i][j];
				changedcubes[i][j] = cubes_[cubeIndex.x][cubeIndex.y][cubeIndex.z];
			}
		}

		//�ؽ�ָ����ϵ
		//Reconstruct index system
		//ֻ����ת����layer����Ӧ��cubes��Ҫ�ع�index
		//Only the cubes corresponding to the rotated layer need to reconstruct the index
		int rotationCase = rotateCountor % 4 < 0 ? rotateCountor % 4 + 4 : rotateCountor % 4;
		int n = 3;

		//�ı�cubes_������
		//Changing Cubes_ Index of
		switch (pickedLayer_.x) {
		case 0://Around the x-axis
			for (int y = 0; y < 3; y++) {
				for (int z = 0; z < 3; z++) {
					if (dragDirection > 0)	cubes_[pickedLayer_.y][y][z] = changedcubes[2 - z][y];
					else cubes_[pickedLayer_.y][y][z] = changedcubes[z][2-y];
					
				}
			}
			break;
		case 1://Around the y-axis
			for (int x = 0; x < 3; x++) {
				for (int z = 0; z < 3; z++) {
					if (dragDirection > 0)cubes_[x][pickedLayer_.y][z] = changedcubes[2-z][x];
					else cubes_[x][pickedLayer_.y][z] = changedcubes[z][2-x];
				}
			}
			break;
		case 2://Around the z-axis
			for (int x = 0; x < n; x++) {
				for (int y = 0; y < n; y++) {
					if (dragDirection > 0) cubes_[x][y][pickedLayer_.y] = changedcubes[2-y][x];
					else cubes_[x][y][pickedLayer_.y] = changedcubes[y][2-x];
				}
			}
			break;

		default:
			break;
		}

		InitLayer();
		rotateCountor = 0;
		pickedCube_ = { -1,-1,-1 };
	}

private:
	void InitLayer()
	{
		for (int x = 0; x < 3; ++x)
		{
			for (int y = 0; y < 3; y++) {
				for (int z = 0; z < 3; z++) {
					layers_[0][x].cubes[y][z] = glm::vec3(x, y, z);	//Using the X-direction as the axis
					layers_[1][y].cubes[x][z] = glm::vec3(x, y, z);//Using the Y-direction as the axis
					layers_[2][z].cubes[x][y] = glm::vec3(x, y, z);//Using the Z-direction as the axis
				}
			}
			layers_[0][x].axis = glm::vec3(1.0, 0.0, 0.0);
			layers_[1][x].axis = glm::vec3(0.0, 1.0, 0.0);
			layers_[2][x].axis = glm::vec3(0.0, 0.0, 1.0);
		}
	}
	uint IndexToStencil(int x, int y, int z) {
		uint result =
			x + 6 * y + 36 * z + 1;
		return result;
	}
	bool StencilToIndex(uint uvalue, glm::ivec3& result) {
		if (uvalue == 0) return false;
		int value = (int)uvalue;
		value -= 1;
		result.z = value / 36;
		value = value % 36; result.y = value / 6;
		value = value % 6; result.x = value;
		return true;
	}
public:
	State State_ = None;
	glm::mat4 Matrix = glm::mat4(1.0);
	glm::mat4 LayerMatrix = glm::mat4(1.0);
	bool InitRotation = true;

	glm::ivec3 pickedCube_{-1,-1,-1};		//�Ҽ������cube������//The coordinates of the right button selected cube
	glm::ivec2 pickedLayer_;	//�Ҽ�ѡ�е���ת��//Right click on the selected layer
	int dragDirection = 1;			//�Ҽ���ק�ķ���////Right button dragging direction
	float RotateSpeed = 150.0f;

	int rotateCountor;		//layer��ת�˼���90��//How many 90 degrees did the layer rotates

private:
	Cube cubes_[3][3][3];	//��Ӧx,y,z������˳��//Corresponding coordinate order of x, y, and z
	Layer layers_[3][3];	//9 layers, with 3 in each direction
	float angle= 0.0f;
	bool isFinish = false;

};
