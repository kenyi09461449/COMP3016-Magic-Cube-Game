#pragma once
#ifndef PCH_H
#define PCH_H
#include <glad/glad.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <direct.h>
#include <vector>
#include <tuple>


using uint = unsigned int;

//The Six Directions of Rubik's Cube
enum Direction
{
	front, back, left, right, up, down
};
//ħ���������ɫ�Լ��ڲ��ĺ�ɫ
//The colors of the six sides of the Rubik's Cube and the black inside
enum Color {
	black, blue, green, orange, pink, red, yellow
};

#endif // PCH_H


