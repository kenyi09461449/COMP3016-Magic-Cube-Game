Click 'Code.exe' file to run Rubik's cube game

Use the right mouse button to drag and drop to rotate one layer of the Rubik's Cube

Use the left mouse button to rotate the perspective.

Use the mouse scroll wheel to zoom in on the perspective.