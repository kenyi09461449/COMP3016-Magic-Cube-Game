#pragma once
#include <glad/glad.h>
#include "glm\glm.hpp"
#include "pch.h"
#include "Texture.h"

//cube�Ķ��㣬���Ϻ��£���ʱ��
//The vertices of the cube, top to bottom, counterclockwise
float CubeVertexs[] = {
	// ǰ//Front
-0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
-0.5f,  0.5f,  0.5f,  0.0f, 1.0f,
 0.5f,  0.5f,  0.5f,  1.0f, 1.0f,
 0.5f,  0.5f,  0.5f,  1.0f, 1.0f,
 0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
-0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
// ��//Back
-0.5f, -0.5f, -0.5f,  0.0f, 0.0f,
-0.5f,  0.5f, -0.5f,  0.0f, 1.0f,
 0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
 0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
 0.5f, -0.5f, -0.5f,  1.0f, 0.0f,
-0.5f, -0.5f, -0.5f,  0.0f, 0.0f,


// ��//Left
-0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
-0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
-0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
-0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
-0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
-0.5f,  0.5f,  0.5f,  1.0f, 0.0f,

// ��//Right
 0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
 0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
 0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
 0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
 0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
 0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
 // ��//Up
-0.5f,  0.5f, -0.5f,  0.0f, 1.0f,
-0.5f,  0.5f,  0.5f,  0.0f, 0.0f,
 0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
 0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
 0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
-0.5f,  0.5f, -0.5f,  0.0f, 1.0f,
// ��//Down
-0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
-0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
 0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
 0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
 0.5f, -0.5f, -0.5f,  1.0f, 1.0f,
-0.5f, -0.5f, -0.5f,  0.0f, 1.0f

};



class Cube
{
public:
	Cube() :Pos_(glm::vec3(0.0, 0.0, 0.0)) {}
	Cube(glm::vec3 pos) :Pos_(pos)
	{
	}
	void Init()
	{
		//������������ݶ��󶨵�opengl
		//Bind the data of the cube to OpenGL
		glGenVertexArrays(1, &vao_);
		unsigned int vbo;
		glGenBuffers(1, &vbo);
		glBindVertexArray(vao_);

		glBindBuffer(GL_ARRAY_BUFFER, vbo);
		glBufferData(GL_ARRAY_BUFFER, sizeof(CubeVertexs), CubeVertexs, GL_STATIC_DRAW);
		// λ������//Location attribute
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
		glEnableVertexAttribArray(0);
		// ������������//Texture coordinate attributes
		glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
		glEnableVertexAttribArray(1);
		PosMatrix_ = glm::translate(PosMatrix_, Pos_);
	}

	void SetColor(Direction dir, Color color) { colors_[dir] = color; }

	void Render(Shader& shader, Texture& texture)
	{
		glBindVertexArray(vao_);
		glEnableVertexAttribArray(1);

		//���ƻ��Ƽ������� 
		//Control how many vertices to draw
		for (int i = 0; i < 6; i++)
		{
			texture.Bind(colors_[i]);
			glDrawArrays(GL_TRIANGLES, i * 6, 6);

		}
	}

public:
	glm::vec3 Pos_;	//λ��//Position
	glm::vec3 eulerAngle = glm::vec3(1.0);	//ŷ����//Euler angle
	glm::mat4 PosMatrix_ = glm::mat4(1.0);
	glm::mat4 RotationMatrix_ = glm::mat4(1.0);

private:
	//��¼�����涼��ʲô��ɫ
	//Record the colors of the six faces
	Color colors_[6]{ orange,yellow,pink,blue,green,red };
	unsigned int vao_;
};

