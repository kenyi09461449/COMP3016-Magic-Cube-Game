#ifndef SHADER_H
#define SHADER_H
#include "pch.h"

class Shader
{
public:
	Shader(std::string vsFile, std::string fsFile);

	void Use()
	{
		glUseProgram(programId_);
	}
    unsigned int GetId() { return programId_; }

    //ʵ�ó���ͳһ����
    // utility uniform functions
    void setBool(const std::string& name, bool value) const
    {
        glUniform1i(glGetUniformLocation(programId_, name.c_str()), (int)value);
    }
    void setInt(const std::string& name, int value) const
    {
        glUniform1i(glGetUniformLocation(programId_, name.c_str()), value);
    }
    void setMat4(const std::string& name, const glm::mat4& mat) const
    {
        glUniformMatrix4fv(glGetUniformLocation(programId_, name.c_str()), 1, GL_FALSE, &mat[0][0]);
    }

private:
	unsigned int CompileShader(std::string& src, unsigned int type);
	void CheckErrors(uint programId_, std::string type);
	std::string ReadFile(std::string path);
private:
	unsigned int programId_;
};
#endif