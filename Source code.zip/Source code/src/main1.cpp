#include "pch.h"
#include <direct.h>
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include "Shader.h"
#include "Camera.h"
#include"Tool.h"
#include "Texture.h"
#include "RubikCube.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include "TraceBall.h"

const int SCR_WIDTH = 800;
const int SCR_HEIGHT = 600;
void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouseMove_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void click_callback(GLFWwindow* window, int button, int action, int mods);
void processInput(GLFWwindow* window);

//��¼�����״̬����
//Record the input state variables
bool leftKey = false, rightKey = false;
glm::vec3 clickPos;
glm::mat4 lastMat = glm::mat4(1.0f);
// camera
Camera camera(glm::vec3(6.5,6.5,6.5),glm::vec3(0.0f,1.0f,0.0f),-133.0,-40.0);
float lastX = SCR_WIDTH / 2.0f;
float lastY = SCR_HEIGHT / 2.0f;
bool firstMouse = true;
//��ʼ��һ���켣������ħ����ָ��
//Initialize a trackball object and a pointer to the Rubik's cube
TraceBall traceBall;
RubikCube* p_rubikCube = nullptr;	

//��ǰ֡����һ֮֡���ʱ��
// time between current frame and last frame
float deltaTime = 0.0f;	
float lastFrame = 0.0f;
int main()
{
	glfwInit();
	glfwInitHint(GLFW_CONTEXT_VERSION_MINOR, 4);
	glfwInitHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwInitHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "RubikCubeGame", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	//����glfw�Ļص�����
	//Set the callback function for glfw
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetCursorPosCallback(window, mouseMove_callback);
	glfwSetScrollCallback(window, scroll_callback);
	glfwSetMouseButtonCallback(window, click_callback);

	//����GLFW�������ǵ����
	// tell GLFW to capture our mouse
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
	//��ʼ��glad
	//Initialize Glad
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}
	//����opengl�ӿ�
	//Create an opengl viewport
	glViewport(0, 0, 800, 600);
	//����opngl��ȫ������
	//Set global properties for opngl
	// -----------------------------
	glEnable(GL_DEPTH_TEST);//������Ȳ���//Begin deep testing
	glEnable(GL_STENCIL_TEST);	//����ģ�����//Begin template testing
	glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);

	//����ħ��
	//Create Rubik's Cube
	RubikCube rubikCube;
	traceBall.RubikCube_p = &rubikCube;
	p_rubikCube = &rubikCube;
	//����shader
	//Create Shader
	Shader shader(Tool::GetCwd() + "\\src\\shader.vs", Tool::GetCwd() + "\\src\\shader.fs");

	//��������
	//Creating textures
	Texture texture({ Tool::GetCwd() + "\\asserts\\black.png",
					 Tool::GetCwd() + "\\asserts\\blue.png",
					 Tool::GetCwd() + "\\asserts\\green.png",
					 Tool::GetCwd() + "\\asserts\\orange.png",
					 Tool::GetCwd() + "\\asserts\\pink.png",
					 Tool::GetCwd() + "\\asserts\\red.png",
					 Tool::GetCwd() + "\\asserts\\yellow.png", });
	//��opengl�н�texture1�󶨵�TEXTURE0
	//Bind texture1 to Texture0 in Opengl
	shader.setInt("texture1", 0);	

	//��Ⱦѭ��
	//Rendering loop
	while (!glfwWindowShouldClose(window))
	{
		processInput(window);
		//ÿ֡ʱ���߼�
		// per-frame time logic
		// --------------------
		float currentFrame = static_cast<float>(glfwGetTime());
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;
		shader.Use();

		//��ͶӰ���󴫵ݸ���ɫ������ע������������£������ܻ����ÿһ֡��
		// pass projection matrix to shader (note that in this case it could change every frame)
		glm::mat4 projection = glm::perspective(glm::radians(camera.Zoom), (float)SCR_WIDTH / (float)SCR_HEIGHT, 1.0f, 1000.0f);
		shader.setMat4("projection", projection);
		//��Ӱ��/��ͼ�任
		// camera/view transformation
		glm::mat4 view = camera.GetViewMatrix();
		shader.setMat4("view", view);
		glm::mat4 model(1.0f);
		shader.setMat4("model", model);
		// render
		glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
		glActiveTexture(GL_TEXTURE0);

		rubikCube.Update(deltaTime, shader, texture);

		glfwSwapBuffers(window);
		glfwPollEvents();
	}
	glfwTerminate();
	return 0;

}



/*����Ļ�ռ������ӳ�䵽[-1,1]��y����Ҫ��ת*/
/*Map the coordinates of screen space to [-1,1], and flip the y-axis*/
glm::vec2 ReMapScreenPos(double xposIn, double yposIn)
{
	return glm::vec2(glm::vec2(xposIn / SCR_WIDTH, yposIn / SCR_HEIGHT) * 2.0f - 1.0f);
}
//�����������룺��ѯGLFW,��֡�Ƿ���/�ͷ�����ؼ�����������Ӧ��Ӧ
// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		camera.ProcessKeyboard(FORWARD, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		camera.ProcessKeyboard(BACKWARD, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		camera.ProcessKeyboard(LEFT, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		camera.ProcessKeyboard(RIGHT, deltaTime);
}
////glfw��ÿ�����ڴ�С�����仯���ɲ���ϵͳ���û�������С��ʱ���ûص������ͻ�ִ��
// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	//ȷ���ӿ����´��ڳߴ���ƥ��
	// make sure the viewport matches the new window dimensions
	glViewport(0, 0, width, height);
}

void click_callback(GLFWwindow* window, int button, int action, int mods) {
	//�����������ʱ�����������Ļ����ת��Ϊ��������洢
	//When the left button is pressed, the clicked screen coordinates will be converted to spherical coordinates for storage
	if (button == GLFW_MOUSE_BUTTON_1) {
		if (action == GLFW_RELEASE) {
			leftKey = false;
			rightKey = false;

			return;
		}
		leftKey = true;
		rightKey = false;
		double keyx, keyy;
		glfwGetCursorPos(window, &keyx, &keyy);
		glm::vec2 p(glm::vec2(keyx / SCR_WIDTH, keyy / SCR_HEIGHT) * 2.0f - 1.0f);
		traceBall.LMouseClick(p);
	}
	else if (button == GLFW_MOUSE_BUTTON_2) {
		double keyx, keyy;
		glfwGetCursorPos(window, &keyx, &keyy);
		//�ɿ��Ҽ�
		//Release the right button
		if (action == GLFW_RELEASE) {
			rightKey = false;
			std::cout << "right click:" << keyx << " " << keyy << std::endl;
			//�������Ҽ���û���ƶ�
			//If there is no movement after clicking the right button
			if (p_rubikCube->InitRotation)
				return;

			//�ɿ��Ҽ�ʱ����ħ����״̬��ʹ�俪ʼ��ת��
			//When releasing the right button, set the state of the Rubik's Cube to start rotating.
			p_rubikCube->State_ = Rotating;
			rightKey = false;
			p_rubikCube->InitRotation = true;
		}
		//����Ҽ�
		//Click right button 
		else
		{
			rightKey = true;
			glm::vec2 p(glm::vec2(keyx / SCR_WIDTH, keyy / SCR_HEIGHT) * 2.0f - 1.0f);
			traceBall.RMouseClick(p);
			p_rubikCube->RightButtonClick(glm::vec2(keyx, keyy));

		}
	}
}
//glfw��ÿ������ƶ�ʱ��������ô˻ص�
// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void mouseMove_callback(GLFWwindow* window, double xposIn, double yposIn)
{
	glm::vec2 mousePos= ReMapScreenPos(xposIn, yposIn);
	if (leftKey) {
		traceBall.MouseMove(mousePos);
	}
	else if (rightKey)
	{
		if (p_rubikCube->State_ == Rotating || p_rubikCube->pickedCube_[0] == -1) return;
		//�ڰ�ס�Ҽ��ƶ��ĵ�һ֡������ȷ����ѡ�е�layer
		//At the first frame of holding down the right button to move, you can determine the selected layer
		if (p_rubikCube->InitRotation) {
			int axis, dir;
			std::tie(axis,dir) = traceBall.CalAxis(mousePos, p_rubikCube->Matrix);
			p_rubikCube->pickedLayer_ = glm::ivec2(axis, p_rubikCube->pickedCube_[axis]);
			p_rubikCube->dragDirection = dir;
			std::cout << "layer " << p_rubikCube->pickedLayer_.x << " " << p_rubikCube->pickedLayer_.y << std::endl
				<< " drag direction " << dir << std::endl;;
			p_rubikCube->InitRotation = false;

		}
	}
}

//glfw��ÿ�������ֹ���ʱ�����ô˻ص�
// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
	camera.ProcessMouseScroll(static_cast<float>(yoffset));
}