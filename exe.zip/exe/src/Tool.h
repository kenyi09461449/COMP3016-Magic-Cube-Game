#pragma once
#include "pch.h"
class Tool
{
public:

	static std::string GetCwd()
	{
		char buf[1000];
		_getcwd(buf, 1000);
		return std::string(buf);
	}
};