#pragma once
#include "pch.h"
#include <string>
#include "stb_image.h"


//��Ҫ��Ⱦ7������ͼ
//7 texture maps render
class Texture
{
private:
	unsigned int texturesId_[7];
public:
	Texture(const std::vector<std::string>& paths)
	{
		if (paths.size() != 7)
		{
			std::cout << "need 7 texture image" << std::endl;
			return;
		}

		for (int i = 0; i < 7; i++)
		{
			glGenTextures(1, &texturesId_[i]);
			glBindTexture(GL_TEXTURE_2D, texturesId_[i]);
			//����������������
			// set the texture wrapping parameters
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
			//�����������˲���
			// set texture filtering parameters
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
			//����ͼ�񣬴�������������mipmaps
			// load image, create texture and generate mipmaps
			int width = 0, height = 0, bpp = 0;
			stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.//����stb_image.h��y���Ϸ�ת���ص�������
			unsigned char* data = stbi_load(paths[i].c_str(), &width, &height, &bpp, 0);
			if (data)
			{
				glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
			}
			else
			{
				std::cout << "Failed to load texture:" << paths[i] << std::endl;
			}
			stbi_image_free(data);
		}

	}
	
	~Texture() {};

	void Bind(Color color) {
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texturesId_[color]);
	}
	void UnBind()
	{
		glBindTexture(GL_TEXTURE_2D, 0);
	};
};