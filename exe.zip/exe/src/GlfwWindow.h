#pragma once
#include "pch.h"
#include <direct.h>
#include <glad/glad.h>
#include <GLFW/glfw3.h>

class GLWindow
{
public:
	static const int SCR_WIDTH = 800;
	static const int SCR_HEIGHT = 600;
	GLWindow() {}
	void Init()
	{
		glfwInit();
		glfwInitHint(GLFW_CONTEXT_VERSION_MINOR, 4);
		glfwInitHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
		glfwInitHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

		window_ = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "RubikCubeGame", NULL, NULL);
		if (window_ == NULL)
		{
			std::cout << "Failed to create GLFW window" << std::endl;
			glfwTerminate();
			return ;
		}
		//����Opengl������
		//Set Opengl Context
		glfwMakeContextCurrent(window_);

		//����glfw������ģʽ
		//Set the input mode for glfw
		glfwSetInputMode(window_, GLFW_CURSOR, GLFW_CURSOR_NORMAL);

		//��ʼ��glad
		//Initialize Glad
		if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
		{
			std::cout << "Failed to initialize GLAD" << std::endl;
			return ;
		}
	}

private:
	GLFWwindow* window_;
};